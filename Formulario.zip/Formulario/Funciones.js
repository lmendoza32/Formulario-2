function validar()
{
	var nombre = document.getElementaryById('nombre').value;
	var paterno = document.getElementaryById('paterno').value;
	var materno = document.getElementaryById('materno').value;
	var bachillerato = document.getElementaryById('bachillerato').value;
	if(nombre.length == 0)
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfrimButton: false,
			timer: 3000
		})
	}
	if(paterno.length == 0)
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfrimButton: false,
			timer: 3000
		})
	}
	if(materno.length == 0)
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfrimButton: false,
			timer: 3000
		})
	}
	if(bachillerato == "Selecciona bachillerato")
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfrimButton: false,
			timer: 3000
		})
	}

}
function validar()
{
	var nombre = document.getElementById('nombre').value;
	var paterno = document.getElementById('paterno').value;
	var materno = document.getElementById('materno').value;
	var bachillerato = document.getElementById('bachillerato').value;
	var sexo = 0;
	if(document.getElementById('hombre').checked == true)
	{
		sexo = 1;
	}
	if(document.getElementById('mujer').checked == true)
	{
		sexo = 2;
	}
	if(sexo == 0)
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el sexo de la persona!',
			showConfirmButton: false,
			timer: 3000
		})
		bandera = 2;
	}


	if(nombre.length == 0)
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfirmButton: false,
			timer: 3000
		})
		bandera = 2;
	}

	if(paterno.length == 0)
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfirmButton: false,
			timer: 3000
		})
		bandera = 2;
	}

	if(materno.length == 0)
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfirmButton: false,
			timer: 3000
		})
		bandera = 2;
	}

	if(bachillerato == "Selecciona bachillerato")
	{
		Swal.fire({
			icon: 'error',
			title: 'Alerta de errror',
			text: 'No puedes dejar el nombre en blanco!',
			showConfirmButton: false,
			timer: 3000
		})
		bandera = 2;
	}

	if(bandera == 1)
	{
		alert("El formulario paso la prueba");
	}
}